"""
Учёт Лошадей на Ипподроме
=========================
Простое веб-приложение для распознавания лошадей на фото с помощью YOLOv8.
Код максимально простой — для студентов 2 курса.

Автор: ИИ-помощник
"""

# ============ ИМПОРТЫ ============
from flask import Flask, render_template, request, jsonify, send_file
import sqlite3
from datetime import datetime
import os
import uuid
import io

from ultralytics import YOLO
import cv2
import numpy as np
from openpyxl import Workbook


# ============ НАСТРОЙКИ ============
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static'
app.config['DATABASE'] = 'history.db'

# Класс лошади в COCO dataset (YOLO обучен на COCO, там class 17 = horse)
HORSE_CLASS = 17

# Загружаем модель YOLOv8 (самая лёгкая версия yolov8n.pt)
# model会自动下载权重文件
print("Загрузка модели YOLOv8...")
model = YOLO('yolov8n.pt')
print("Модель загружена!")


# ============ РАБОТА С БАЗОЙ ДАННЫХ ============

def init_db():
    """
    Создаёт таблицу в БД, если её ещё нет.
    Вызывается при каждом запуске приложения.
    """
    conn = sqlite3.connect('history.db')
    cursor = conn.cursor()
    
    # Создаём таблицу с полями:
    # id - порядковый номер (автоинкремент)
    # filename - имя загруженного файла
    # result_filename - имя обработанного файла
    # count - сколько лошадей найдено
    # timestamp - когда обработали
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS detections (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            result_filename TEXT,
            count INTEGER,
            timestamp DATETIME
        )
    ''')
    
    conn.commit()
    conn.close()
    print("База данных инициализирована!")


def save_to_db(filename, result_filename, count):
    """
    Сохраняет одну запись в базу данных.
    
    Параметры:
        filename - имя загруженного файла
        result_filename - имя файла с результатом
        count - количество найденных лошадей
    """
    conn = sqlite3.connect('history.db')
    cursor = conn.cursor()
    
    # Вставляем новую запись
    cursor.execute('''
        INSERT INTO detections (filename, result_filename, count, timestamp)
        VALUES (?, ?, ?, ?)
    ''', (filename, result_filename, count, datetime.now()))
    
    conn.commit()
    conn.close()


def get_all_records():
    """
    Получает все записи из базы данных.
    Возвращает список кортежей (id, filename, count, timestamp).
    """
    conn = sqlite3.connect('history.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        SELECT id, filename, result_filename, count, timestamp
        FROM detections
        ORDER BY id DESC
    ''')
    
    records = cursor.fetchall()
    conn.close()
    
    return records


# ============ ОБРАБОТКА ИЗОБРАЖЕНИЙ ============

def process_image(image_file):
    """
    Обрабатывает изображение: находит лошадей через YOLO и рисует рамки.
    
    Параметры:
        image_file - загруженный файл из формы
    
    Возвращает:
        result_filename - имя сохранённого файла с результатом
        horse_count - количество найденных лошадей
    """
    # Читаем изображение из байтов
    image_bytes = np.frombuffer(image_file.read(), np.uint8)
    image = cv2.imdecode(image_bytes, cv2.IMREAD_COLOR)
    
    # Пропускаем через YOLO модель
    # conf=0.25 означает, что берём объекты с уверенностью > 25%
    results = model(image, conf=0.25)
    
    # Считаем только лошадей (класс 17 в COCO)
    horse_count = 0
    for result in results:
        # boxes содержит все найденные объекты
        if result.boxes is not None:
            for box in result.boxes:
                # box.cls[0] - номер класса обнаруженного объекта
                if int(box.cls[0]) == HORSE_CLASS:
                    horse_count += 1
    
    # Рисуем рамки вокруг найденных объектов
    # results[0].plot() возвращает изображение с нарисованными рамками
    result_image = results[0].plot()
    
    # Создаём уникальное имя файла (timestamp + случайное число)
    unique_id = str(uuid.uuid4())[:8]
    result_filename = f'result_{unique_id}.jpg'
    result_path = os.path.join('static', result_filename)
    
    # Сохраняем результат в папку static
    cv2.imwrite(result_path, result_image)
    
    print(f"Обработано! Найдено лошадей: {horse_count}")
    
    return result_filename, horse_count


# ============ МАРШРУТЫ FLASK ============

@app.route('/')
def index():
    """Главная страница - отдаём форму загрузки фото."""
    return render_template('index.html')


@app.route('/history')
def history():
    """Страница истории - показываем все обработки."""
    records = get_all_records()
    return render_template('history.html', records=records)


@app.route('/process', methods=['POST'])
def process():
    """
    Обрабатывает загруженное фото.
    Принимает POST-запрос с файлом изображения.
    Возвращает JSON с результатами.
    """
    try:
        # Проверяем, что файл передан
        if 'file' not in request.files:
            return jsonify({'error': 'Файл не загружен'}), 400
        
        file = request.files['file']
        
        # Проверяем, что файл выбран
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400
        
        # Обрабатываем изображение
        result_filename, count = process_image(file)
        
        # Сохраняем в базу данных
        save_to_db(file.filename, result_filename, count)
        
        # Возвращаем результат в JSON
        return jsonify({
            'success': True,
            'count': count,
            'image': result_filename
        })
        
    except Exception as e:
        # Если ошибка - возвращаем текст ошибки
        return jsonify({'error': str(e)}), 500


@app.route('/download')
def download_excel():
    """
    Скачивание истории в формате Excel.
    Генерирует .xlsx файл и отдаёт пользователю.
    """
    # Получаем все записи из БД
    records = get_all_records()
    
    # Создаём новую книгу Excel
    wb = Workbook()
    ws = wb.active
    ws.title = "История обнаружений"
    
    # Заголовки таблицы
    ws.append(['№', 'Имя файла', 'Результат (файл)', 'Кол-во лошадей', 'Время'])
    
    # Добавляем каждую запись в таблицу
    for record in records:
        ws.append([
            record[0],           # id
            record[1],           # filename
            record[2],           # result_filename
            record[3],           # count
            record[4]            # timestamp
        ])
    
    # Сохраняем в буфер памяти
    buffer = io.BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    
    # Отдаём файл пользователю
    return send_file(
        buffer,
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        as_attachment=True,
        download_name='history_horse_detection.xlsx'
    )


# ============ ЗАПУСК ПРИЛОЖЕНИЯ ============
if __name__ == '__main__':
    # Инициализируем базу данных
    init_db()
    
    # Запускаем Flask на порту 5000
    # host='0.0.0.0' - доступ с любого IP
    # debug=True - автоперезагрузка при изменениях
    print("\n" + "="*50)
    print("Приложение запущено!")
    print("Откройте в браузере: http://localhost:5000")
    print("="*50 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
